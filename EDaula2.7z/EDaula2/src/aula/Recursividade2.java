package aula;

public class Recursividade2 {
	
	public int multiplicacaoRecursiva(int multiplicador, int multiplicando) {
		// 1 - Chamada
		
		if (multiplicando == 0) {
			return 0;
		} else {
			return multiplicador + multiplicacaoRecursiva(multiplicador, multiplicando - 1);
		}
		// 2 - Condição de parada
	}

}
